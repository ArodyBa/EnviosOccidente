// server.js
const config = require('./config/environment');
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

// Auth
const authRoutes = require('./routes/auth');
const { verifyJWT } = require('./middlewares/auth.middleware');

// Routes negocio
const clientesRoutes = require('./routes/clientes');
const presatmosRoutes = require('./routes/prestamos');
const productosRoutes = require('./routes/productos');
const proveedoresRoutes = require('./routes/proveedores');
const comprasRoutes = require('./routes/compras');
const ventasRoutes = require('./routes/ventas');
const categoriasRoutes = require('./routes/categorias');
const abonosRoutes = require('./routes/abonos');
const reportesRoutes = require('./routes/reportes');
const correccionesRoutes = require('./routes/correcciones');
const facturacionRoutes = require('./routes/facturacionRoutes');
const facturasRoutes = require('./routes/facturas');
const tipoDocumentosRoutes = require('./routes/tipoDocumentos');
const papeleriaRoutes = require('./routes/papeleria');
const enviosRoutes = require('./routes/envios');
const sliderRoutes = require('./routes/slider');

const app = express();

app.set('trust proxy', 1);

// ===== CORS (flexible en dev) =====
app.use((req, res, next) => {
  const origin = req.headers.origin;
  const allowAllDev = (config.NODE_ENV === 'development');
  const allowed = /^https?:\/\/([a-z0-9-]+\.)*gtpos\.xyz$/i.test(origin || '');
  if (!origin) {
    res.header('Access-Control-Allow-Origin', '*');
  } else if (allowAllDev || allowed) {
    res.header('Access-Control-Allow-Origin', origin);
  }
  res.header('Vary', 'Origin');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Upload-Token');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const corsOptions = {
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);
    if (config.NODE_ENV === 'development') return cb(null, true);
    const allowed = /^https?:\/\/([a-z0-9-]+\.)*gtpos\.xyz$/i;
    return allowed.test(origin) ? cb(null, true) : cb(new Error('No permitido por CORS'));
  },
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Upload-Token'],
  credentials: true,
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

app.use(express.json());

// Health
app.get('/health', (req, res) => {
  res.json({ ok: true, env: config.NODE_ENV, time: new Date().toISOString() });
});

// Static uploads
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Multer
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const subdir = (req.query.subdir || '').replace(/^\/*/, '');
    const base = path.join(process.cwd(), 'uploads');
    const target = subdir ? path.join(base, subdir) : base;
    ensureDir(target);
    cb(null, target);
  },
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^\w.\- ]+/g, '_');
    cb(null, `${Date.now()}-${safe}`);
  },
});
const upload = multer({ storage });

app.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, message: 'No file' });
  const absUploads = path.join(process.cwd(), 'uploads') + path.sep;
  const relPath = req.file.path.replace(absUploads, '').replace(/\\/g, '/');
  const base = `${req.protocol}://${req.get('host')}`;
  const publicUrl = `${base}/uploads/${relPath}`;
  res.json({ ok: true, url: publicUrl, relative_path: `uploads/${relPath}`, name: req.file.originalname, mime_type: req.file.mimetype, size_bytes: req.file.size });
});

// ===== AUTH =====
app.use('/auth', authRoutes);

// Endpoints publicos (definir antes de rutas protegidas)
app.get('/slider', async (req, res) => {
  try {
    const ctrl = require('./controllers/sliderController');
    return ctrl.listPublic(req, res);
  } catch (e) { res.status(500).json({ message: 'Error interno' }); }
});
app.get('/tracking/:code', async (req, res) => {
  try {
    const ctrl = require('./controllers/enviosController');
    return ctrl.getTrackingByCode(req, res);
  } catch (e) { res.status(500).json({ message: 'Error interno' }); }
});// Endpoints p�blicos para Precios (solo lectura)
app.get('/envios/tipos', async (req, res) => {
  try {
    const ctrl = require('./controllers/enviosController');
    return ctrl.getTiposEnvio(req, res);
  } catch (e) { res.status(500).json({ message: 'Error interno' }); }
});
app.get('/envios/tarifas', async (req, res) => {
  try {
    const ctrl = require('./controllers/enviosController');
    return ctrl.getTarifasEnvio(req, res);
  } catch (e) { res.status(500).json({ message: 'Error interno' }); }
});

// Endpoints p�blicos (definir antes de rutas protegidas)

// ===== RUTAS PROTEGIDAS =====
app.use('/clientes', verifyJWT, clientesRoutes);
app.use('/prestamos', verifyJWT, presatmosRoutes);
app.use('/productos', verifyJWT, productosRoutes);
app.use('/proveedores', verifyJWT, proveedoresRoutes);
app.use('/compras', verifyJWT, comprasRoutes);
app.use('/ventas', verifyJWT, ventasRoutes);
app.use('/categorias', verifyJWT, categoriasRoutes);
app.use('/abonos', verifyJWT, abonosRoutes);
app.use('/reportes', verifyJWT, reportesRoutes);
app.use('/correcciones', verifyJWT, correccionesRoutes);
app.use('/facturacion', verifyJWT, facturacionRoutes);
app.use('/facturas', verifyJWT, facturasRoutes);
app.use('/tipo-documentos', verifyJWT, tipoDocumentosRoutes);
app.use('/papeleria', verifyJWT, papeleriaRoutes);
app.use('/envios', verifyJWT, enviosRoutes);
app.use('/slider', verifyJWT, sliderRoutes);

// P�blico: tracking + slider

// ===== Arranque =====
console.log(`Servidor ejecut�ndose en modo: ${config.NODE_ENV}`);
app.listen(config.PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${config.PORT}`);
});
